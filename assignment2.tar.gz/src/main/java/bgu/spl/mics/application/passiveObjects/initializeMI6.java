package bgu.spl.mics.application.passiveObjects;

import java.io.FileReader;


public class initializeMI6 {




}

