package bgu.spl.mics.application.messages;


import bgu.spl.mics.Event;
import bgu.spl.mics.application.passiveObjects.Agent;

import java.util.List;
import java.util.Map;

public class AgentsAvailableEvent implements Event {

    private List<String> serial;

    public AgentsAvailableEvent (List<String> serial){
        this.serial=serial;
    }

    public List<String> getSerial(){
        return serial;
    }
}